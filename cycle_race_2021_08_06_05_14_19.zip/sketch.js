var sword,  swordImage, enemyG, enemyImage, fruit1,fruit2, fruit3
         fruit4,  fruitG, fruitImage,  fruit1Image, fruit3Image,fruit4Image,
  score,gameOverImage
var PLAY=1
var END=0
var  gameState=PLAY



function preload() {
   swordImage=loadImage("sword.png")
   enemyImage=loadImage("alien1.png") 
   fruit1Image=loadImage ("fruit1.png")
   fruitImage2=loadImage ("fruit2.png")
   fruitImage3=loadImage ("fruit3.png")
   fruitImage4ImageImage("fruit4.png")
   gameOverImage=loadImage("gameover.png")
}
  
function setup(){
  createCanvas(600,600);
  
   sword=createSprite(200,200,100,100)
   sword.addImage(swordImage)
   sword.scale=0.5


enemyG= new Group()
fruitG= new Group()

  
  score=0
  
} 
  
 function draw(){ 
background("skyblue") 
  
 }
  
if (gameState===PLAY){
  sword.x=World.mouseX
  sword.y=World.mouuseY
}
  var select_item = Math.round(random(1,5));
   if(World.frameCount%100===0)
 if(select_item==1){
   fruit1()
 }  else if (select_item==2){
   enemy()
  
 } else if (select_item==3){ 
   enemy()
   
 }  elsEache if (select_item==4){
    (0)
   fruitsG.setVelocityXEach(0)
   sword.addImage(gameoverImage)
   sword.scale=2
 }          
   
   
  if(sword.istounching(enemyG)){ 
   enemyG.destoryEach()
   gameState=END
   fruitsG.destoryEach()
   enemyG.setVelocity(0)
   fruitsG.setVelocityXEach(0)
   sword.addImage(gameOverImage)
  sword.scale=2
   
   
   
   
   
   
  drawSprite ();
   
   
  text("Score: "+ score, 500.50); 
   
   
   
  function enemy(){
   
   var
   enemy=createSprites(600,Math.round(random30,400))(10,10)
   
 enemy. addImage(enemyImage)  
   enemy.velocityX=-6 
  enemy.scale=0.75
  enemy.ifeTime=150
  enemyG.add(eneemy)  
    
  }    
    
    
   function fruit1(){
    var
fruiti=createSprite(600,ath.round(random(30,400)),10,10)
      fruit1.addImage(fruit1Image)
    fruit1velocityX=-6
    fruit1.velocityX=-6
    fruit.scale=0.2
    fruite.lifttime=150
    fruitG.add(Fruit1)
   }
    
    
  function fruit2(){
 var
    
  fruit2=createSprite(600,Math.round(random(30,300)),10,10)
    fruit2.addImage(fruit2Image)
   fruit2.velocityX=-6
  fruit2.scale=0.2
fruit2.ifteTime=150
   fruitsG.add(fruits)
    
  } 